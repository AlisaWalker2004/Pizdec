package ru.andreeva.numbers

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Random
import java.util.Timer
import kotlin.concurrent.timer


class MainActivity : AppCompatActivity() {

    lateinit var etNumber: EditText
    lateinit var tvInfo:TextView
    lateinit var tvPopitki:TextView
    lateinit var tvName: TextView
    lateinit var btn:Button
    lateinit var tvTimer : TextView

    var rnd = Random()
    var number: Int = 0

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etNumber = findViewById(R.id.etNumber)
        tvInfo = findViewById(R.id.tvInfo)
        tvPopitki = findViewById(R.id.tvPopitki)
        btn = findViewById(R.id.btn)

        tvName = findViewById(R.id.tvName)
        var userText = intent.extras?.getString("userText")
        tvName.text = userText

        tvTimer = findViewById(R.id.tvTimer)
        var timeText = intent.extras?.getString("timeText")
        tvTimer.text = timeText

        var timer1 = Timer()

        number = rnd.nextInt(101)
    }
    private var count:Int = 10

    /*var time1 : Int = tvTimer.text.ToLong()

    val timer = object: CountDownTimer(time1.toLong(), 1) {
        override fun onTick(millisUntilFinished: Long) {...}

        override fun onFinish() {...}
    }
    timer.start()
     */


    fun onClick(view: View) {

        if (etNumber.text.toString().equals("") == false)
        {
            count-=1
            if(count!=0) {
                var strK = count.toString()
                var chislo: Int = etNumber.text.toString().toInt()
                if (chislo > number) tvInfo.text = getText(R.string.big)
                if (chislo < number) tvInfo.text = getText(R.string.small)
                if (chislo == number)
                {
                    var strK = count.toString()
                    tvPopitki.text = strK + " попыток"
                    tvInfo.text = getText(R.string.equal)
                    val intent = Intent(this@MainActivity, SecondActivity::class.java)
                    intent.putExtra("userText", tvInfo.text.toString())
                    intent.putExtra("popitka", tvPopitki.text.toString())
                    startActivity(intent)
                    number = rnd.nextInt(101)
                    /*
                    btn.isVisible = false
                    btnRestart.isVisible = true
                    btnFinish.isVisible = true
                     */
                }
                tvPopitki.text = strK + " попыток"
            }
            else if(count == 0){
                var strK = count.toString()
                tvInfo.text = "Ты лузер"
                tvPopitki.text = strK + " попыток"
                val intent = Intent(this@MainActivity, SecondActivity::class.java)
                intent.putExtra("userText", tvInfo.text.toString())
                intent.putExtra("num","Загаданное число: " + number)
                startActivity(intent)
                number = rnd.nextInt(101)
                /*
                btn.isVisible = false
                btnRestart.isVisible = true
                btnFinish.isVisible = true
                 */

            }
        }
        else
        {
            tvInfo.text = "Пусто, выросла капуста"
        }

    }
}